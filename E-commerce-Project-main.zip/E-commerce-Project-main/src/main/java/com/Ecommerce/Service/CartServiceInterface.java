package com.Ecommerce.Service;

import com.Ecommerce.Entity.User;

public interface CartServiceInterface {
	
	public void addCartDetails(User user );
	

	
}
