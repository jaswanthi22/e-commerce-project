package com.Ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceBackendProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommerceBackendProjectApplication.class, args);
	}

}
